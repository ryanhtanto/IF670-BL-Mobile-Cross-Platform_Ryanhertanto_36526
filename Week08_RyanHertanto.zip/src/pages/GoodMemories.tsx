import { IonButton, IonButtons, IonCard, IonCardHeader, IonCardTitle, IonCol, IonContent, IonFab, IonFabButton, IonGrid, IonHeader, IonIcon, IonPage, IonRow, IonTitle, IonToolbar, isPlatform } from "@ionic/react"
import { add } from "ionicons/icons"
import MemoryItem from '../components/MemoryItem'
const GoodMemories: React.FC = () => {
    // const memoriesCtx = useContext(MemoriesContext)
    // const goodMemories = memoriesCtx.memories.filter(memory => memory.type === 'good')

    return(
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Good Memories</IonTitle>
                    {isPlatform("ios") && (
                    <IonButtons slot="end">
                        <IonButton routerLink="/NewMemory">
                            <IonIcon icon={add} />
                        </IonButton>
                    </IonButtons>
                    )}
                </IonToolbar>
            </IonHeader>

            <IonContent>     
                {isPlatform("android") && (
                    <IonFab vertical="bottom" horizontal="end" slot="fixed">
                    <IonFabButton routerLink="/NewMemory">
                        <IonIcon icon={add} />
                    </IonFabButton>
                    </IonFab>
                )}
                <MemoryItem memory={"good"} />
            </IonContent>
        </IonPage>
    )
}

export default GoodMemories